import React from 'react';
import { Link } from 'react-router-dom';

export default function HomePostList(props) {
  // const getSelectedContentList = (selectedType) => {
  //   const filteredData = props.allPostList.filter(
  //     (contentData) => contentData.type == selectedType
  //   );
  //   return filteredData.map((filteredContentData) => (
  //     <div className="content_list_item">
  //       <span className="type_value">
  //         {filteredContentData.type}
  //       </span>

  //       <img
  //         src={filteredContentData.profileImg}
  //         alt={filteredContentData.name + " Profile Image"} />

  //       <div className="content_main_info">
  //         <h2>
  //           {filteredContentData.name}
  //         </h2>
  //         <img
  //           src={"/img/tier/" + filteredContentData.tier + ".jpg"}
  //           alt={filteredContentData.tier + " Image"} />
  //         <span>
  //           {filteredContentData.memberCount + "명"}
  //         </span>
  //       </div>

  //     </div>
  //   ));
  // };




  const getPostList = () => {
    return props.allPostList.map((contentData) => (
      <div className="post_list_item">
        <div className="category_area">
          <span className="big_category_value">
            {contentData.category.big} 
          </span>
          <span className="middle_category_value">
            {contentData.category.middle} 
          </span>
          <span className="small_category_value">
            {contentData.category.small}
          </span>
        </div>

        <h2 className="title">
          <Link>{contentData.title}</Link>
        </h2>

        <div className="user_area">
          <img
            src={contentData.author.profileImg}
            alt="작성자 프로필 이미지" />
          <Link >
            {contentData.author.userName}
          </Link>
        </div>
      </div>
    ));
  };





  return (
    <div id="home_normal_post_list">
      {/* tab content */}
      <section className="content_list_body" aria-labelledby="normal_post">
        {getPostList()}
      </section>
    </div>
  )
}
