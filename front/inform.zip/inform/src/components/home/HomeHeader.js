import React from 'react';

export default function HomeHeader() {
  return (
    <header id="home_header">
      <div className="logo_area">
        <img src="" alt="logo_img" />
        <h1>인폼</h1>
      </div>


      <div className="btn_area">
        <button className="search_btn" type="button" >검색</button>
        <button className="alim_btn" type="button">알림</button>
      </div>


    </header>
  )
}
