import React from 'react';

export default function HomeTabMenu() {
  return (
    <ul id="home_tab_menu" role="tablist" aria-label="홈 탭메뉴">
    <li id="normal_post" role="tab" aria-selected="true">
      일반 포스트
    </li>

    <li id="cash_post" role="tab" aria-selected="false">
      캐쉬 포스트
    </li>
  </ul>
  )
}
