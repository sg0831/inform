import React from 'react'

export default function Post() {
  return (
    <div>Post</div>
  )
}
