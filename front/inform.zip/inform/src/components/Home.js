import React from 'react';
import HomeHeader from './home/HomeHeader';
import HomeTabMenu from './home/HomeTabMenu';
import HomePostList from './home/HomePostList';
import MainNav from './MainNav';


export default function Home(props) {
  return (
    <div id="home">
      <HomeHeader />
      <MainNav />
      <HomeTabMenu />
      <main id="home_main">
        <HomePostList allPostList={props.allPostList} />
      </main>

    </div>
  )
}
