import React from 'react';
import { Link } from 'react-router-dom';

export default function MainNav() {
  return (
    <nav className="main_nav">
      <ul>
        <li><Link>
          홈
        </Link></li>
        <li><Link>
          마이폼
        </Link></li>
        <li><Link>
          더보기
        </Link></li>
      </ul>
    </nav>
  )
}
