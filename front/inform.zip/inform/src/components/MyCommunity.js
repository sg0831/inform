import React from 'react'
import { Link } from 'react-router-dom'

export default function MyCommunity(props) {
  const community = props.community;

  return (
    <div className="MyCommunity">


    <header className="MyCommunity_header">

    <Link to="/">뒤로가기</Link>

    <h2 className="community_title">{ community.title }</h2>

    <button className="search_btn" type="button">검색</button>
    <button className="member_list_btn" type="button">멤버 목록</button>

    </header>








    <main>


    <div className="community_info_area">

    <img
      src={ community.profile_img }
      alt={ community.title + " Profile Image" } />

      <div className="community_meta_info">
        <span className="title">
          { community.title }
        </span>
        <span className="title">
          { community.bigCategory }
        </span>
        <span className="title">
          { community.smoalCategory }
        </span>
        <span className="title">
          { community.memberCount }
        </span>
        <span className="title">
          { community.createdDate }
        </span>
      </div>

    </div>


    </main>


    </div>
  )
}
