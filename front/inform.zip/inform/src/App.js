import { Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './components/Home';




function App() {

  const allPostList = [
    {
    "id": 1,
    "category": {"big": "스크랩", "middle": "맛집", "small": "분식"},
    "title": "연세대 주변 떡볶이 맛집 TOP 10 리스트!",
    "text": "안녕하세요? <br>오늘은 제가 다니고 있는 연세대학교 주변에 떡볶이집을 소개해드리려고 합니다. <br>연세대 주변에는 정말 많은 맛집이 있어요. 하지만 이런 점 때문에 오히려 식당을 고르는데 너무 많은 고민을 하게 되는 문제가 있어요 ㅠㅠ <br>그래서 수많은 맛집 중에서도 떡볶이 맛집에 대해서만 제가 선별한 목록을 알려드리려고 합니다.",
    "author": {"id": "test01", "userName": "연세떡돼녀", "profileImg": "/img01.jpg"},
    "createdDate": "2022-11-01 19:00:00",
    "updatedDate": "2022-11-01 19:00:00"
  },
  {
    "id": 2,
    "category": {"big": "리뷰", "middle": "놀이", "small": "체험"},
    "title": "연인과의 행복한 추억을 만들어준 한강 오리배 솔직한 리뷰 이야기",
    "text": "안녕하세요? <br>지난 주에 여자친구와 함께 한강 데이트를 즐겼는데, 이때 탔던 오리배가 너무 좋은 기억으로 남아 이곳에 정보를 공유하려고 해요. <br>장소: 뚝섬유원지역 4번 출구 <br>비용: 3인용 전동 기준 30분에 20,000원 ",
    "author": {"id": "test02", "userName": "오리의꿈", "profileImg": "/img01.jpg"},
    "createdDate": "2022-11-02 19:00:00",
    "updatedDate": "2022-11-02 19:00:00"
  },
];


  return (
    <div className="App">


      <Routes>
        <Route path="/" element={ <Home allPostList={allPostList} />} />
      </Routes>


    </div>
  );
}

export default App;
